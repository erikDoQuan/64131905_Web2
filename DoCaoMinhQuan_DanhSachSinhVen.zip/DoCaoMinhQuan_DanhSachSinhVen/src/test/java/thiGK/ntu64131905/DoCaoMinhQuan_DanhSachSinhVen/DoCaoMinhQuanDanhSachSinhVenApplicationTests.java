package thiGK.ntu64131905.DoCaoMinhQuan_DanhSachSinhVen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoCaoMinhQuanDanhSachSinhVenApplicationTests {

	@Test
	void contextLoads() {
	}

}
