package thiGK.ntu64131905.DoCaoMinhQuan_DanhSachSinhVen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoCaoMinhQuanDanhSachSinhVenApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoCaoMinhQuanDanhSachSinhVenApplication.class, args);
	}

}
