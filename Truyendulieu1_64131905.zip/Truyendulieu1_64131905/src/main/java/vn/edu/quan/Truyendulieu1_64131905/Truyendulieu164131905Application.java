package vn.edu.quan.Truyendulieu1_64131905;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Truyendulieu164131905Application {

	public static void main(String[] args) {
		SpringApplication.run(Truyendulieu164131905Application.class, args);
	}

}
