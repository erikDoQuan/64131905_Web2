package vn.edu.quan.Truyendulieu1_64131905;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Truyendulieu164131905ApplicationTests {

	@Test
	void contextLoads() {
	}

}
