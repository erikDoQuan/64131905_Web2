package vn.edu.quan.HelloSpringBoot_64131905;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBoot64131905ApplicationTests {

	@Test
	void contextLoads() {
	}

}
